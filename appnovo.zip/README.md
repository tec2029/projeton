Um projeto web básico usando Flask. 

## Como executar 

1. Instale as dependências:
	
bash
pip install -r requirements.txt
